# Zeb Nemeth, May 2020


import networkx as nx
import matplotlib.pyplot as plt
import math
import numpy as np
import pandas as pd

idx = pd.IndexSlice             # needed for slicing multi-index dataframes (pandas)

'Cone variables'
nCones = 1 #The number of cones (communities)
nLevels = 3 #The number of levels per cone


nNodes = np.array(4) #The number of nodes in the highest level
nInferiors = 3
for i in range(1,nLevels): 
    nNodes = np.append(nNodes,np.max(nNodes)*nInferiors) # Example: with 3 levels of 2 inferiors this creates [4,8,16]

#Number of neighbors per node in the ring. Example with 3 levels: [2,4,6]
nRingNeighbors = (np.arange(nLevels)+1)*2

'Number of entries determines number of runs'
weightNeutral = 0.4  # Weights on the same ring
weights_up = [0.3, 0.2 , 0.1, 0.05]       # Weight from inferior to superior
weights_down = [0.8, 0.7, 0.6 , 0.5]     # Weight from your boss and the world on your shoulders

'Variables for interconal edge creation'
interconal = False
friendliness = .2
friendQuality = .9
friendQualityBackwards = .9 # Who knows how balanced the friendship is...
friendLevel = nLevels # Set to nLevels for lowest level

'run variables'
runs = 10 # number of total runs
tmax = 15 # number of timesteps

'seeding varinables'
ini_convinced = 3   # number of initally convinced nodes
ini_convinced_neighbors = 2 # number of neighbors of initially convinced node, that are already convinced
level_start = 1 # level in which to seed

'convincing variables'
cumulative = True
to_convince = 2 # number of neighbors a node convinces in one timestep
#to_convince = list(range(0, 5)) # for a range in number to convince
draining = 0.1 #Draining per timestep

