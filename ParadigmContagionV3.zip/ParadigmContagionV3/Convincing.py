# -*- coding: utf-8 -*-
"""
Created on Mon May 18 09:15:56 2020
@author: luja
"""
import random as random
import sys
import networkx as nx

def seeding(G, ini_convinced, ini_convinced_neighbors, level_start, getNodes, getLevelnr):
    # nr_convinced: number of initally convinced nodes
    # nr_convinced_neighbors: number of neighbors of initially convinced node, that are already convinced
    # level_start: level in which to seed
    seedingTry = 1 #How many times seeded
    while True:
        if seedingTry == 10:
            print('Seeding failed too often, procedure stopped')
            sys.exit()
    
        nx.set_node_attributes(G, 0, name='conv_lev') 
        # access attribute as G.node['0_0_0']['conv_lev']
    
        'choosing initially convinced nodes and their convinced neighbors'
        convinced = random.sample(getNodes(G, levelnr = level_start),ini_convinced)
        
        for i in range(0, ini_convinced):
            neighbors = list(G[convinced[i]])
    
            #Neighbors which cannot be convinced are excluded
            for neighbor in neighbors[:]:
                if neighbor in convinced or getLevelnr(neighbor) != level_start:
                    neighbors.remove(neighbor)
    
            #If not enough neighbors are left for seeding
            if len(neighbors) < ini_convinced_neighbors:
                break
            
            neighborsToConvince = random.sample(neighbors,ini_convinced_neighbors)
            convinced.extend(neighborsToConvince)
        seeding = len(convinced)
    
        for node in convinced:
            G.node[node]['conv_lev']=1
        
        'check if seeding has worked and otherwise stop code execution'
        if seeding == (ini_convinced+ini_convinced*ini_convinced_neighbors):
            print('Seeding complete')
            print('Initially convinced nodes: '+ str(seeding))
            convinced.sort()
            print(convinced)
            break
        else:
            print('Seeding error, starting over again')
            seedingTry += 1
            continue
    return convinced

def convincing_cumulative(G, seeded, tmax, to_convince, draining):
#conv = ['convinced', 'time t', 'r'] #list with values for convinced nodes, timestep and r. - to be set up later if needed
    # tmax maximum amount of timesteps
    # runs
    # convincing_threshold = 1 #treshold
    # draining = 0.1 #Draining per timestep
    # to_convince = 2 # number of neighbors a node convinces in one timestep
   
    convincing_threshold = 1
    nodes = list(G.nodes()) # unique IDs of the nodes
    conv_time = [0] * (1+tmax)
    conv_time[0]=len(seeded)
    
    conv_tot = [0] * (1+tmax)
    conv_tot[0]=len(seeded)
    convinced=[]
    convinced.extend(seeded)
        
    'looping for tmax timesteps'
    for t in range (0,tmax):
        'Convinced nodes spread information'
        for node in convinced:
            neighbors = list(G[node])
    
            #Weight is added to random selection of those neighbors
            if len(neighbors)>to_convince:
                chosen=random.sample(neighbors,to_convince)
                for j in chosen:
                    G.node[j]['conv_lev']+=G[node][j][0]['weight']
                    
            elif len(neighbors)>0:
                for j in neighbors:
                    G.node[j]['conv_lev']+=G[node][j][0]['weight']
    
        'Nodes are convinced and not convinced nodes lose some information'
        for node in nodes:
            if node in convinced:
                continue
    
            #Nodes are convinced
            if G.node[node]['conv_lev'] >= convincing_threshold:
                convinced.append(node)
                conv_time[t+1] += 1
                
    
            #Not convinced nodes lose some information
            else:
                G.node[node]['conv_lev'] -= draining
                if G.node[node]['conv_lev'] < 0:
                    G.node[node]['conv_lev'] = 0
    
        #print('At timestep ' + str(t) + ', ' + str(conv_time[t+1]) + ' were convinced')
        convinced.sort()
        conv_tot[t+1]= len(convinced)
        if len(convinced)==len(nodes):
            #print('All nodes are convinced')
            for skipped_t in range(t, tmax):
                conv_tot[skipped_t+1] = len(convinced)
            break                #if all nodes are convinced, stop process
        if t == tmax-1:
            print('Time ended before consensus')
    'storing data'
    consensus = (len(convinced)/len(nodes))*100
       
    if sum(conv_time)==(len(convinced)):
        cover = True
    else:
        cover = False
        
    return conv_tot, consensus, cover 
