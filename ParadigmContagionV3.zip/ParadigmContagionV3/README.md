# ComplexContagion

Luja, Aart, Grigorios and Zeb
are in a project team on complex systems

We attempt to run a model of paradigm shift in a hierarchical organisation.
