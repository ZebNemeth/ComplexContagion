# Zeb Nemeth, May 2020


import networkx as nx
import matplotlib.pyplot as plt
import math
import numpy as np
import pandas as pd

idx = pd.IndexSlice             # needed for slicing multi-index dataframes (pandas)

'Cone variables'
nCones = 1 #The number of cones (communities)
nLevels = 5 #The number of levels per cone


nNodes = np.array(4) #The number of nodes in the highest level
nInferiors = 3
for i in range(1,nLevels): 
    nNodes = np.append(nNodes,np.max(nNodes)*nInferiors) # Example: with 3 levels of 2 inferiors this creates [4,8,16]

#Number of neighbors per node in the ring. Example with 3 levels: [2,4,6]
nRingNeighbors = (np.arange(nLevels)+1)*2

'Number of entries determines number of runs'
weightNeutral = 0.25  # Weights on the same ring
weights = [0.45, 0.35, 0.15, 0.05]       # Weight from inferior to superior

'Variables for interconal edge creation'
interconal = False
friendliness = .2
friendQuality = .9
friendQualityBackwards = .9 # Who knows how balanced the friendship is...
friendLevel = nLevels # Set to nLevels for lowest level

'run variables'
runs = 10 # number of total runs
tmax = 200 # number of timesteps

'seeding varinables'
ini_convinced = 1   # number of initally convinced nodes
ini_convinced_neighbors = 2 # number of neighbors of initially convinced node, that are already convinced
level_start = 2 # level in which to seed

'convincing variables'
cumulative = True
to_convince = 2 # number of neighbors a node convinces in one timestep
#to_convince = list(range(0, 5)) # for a range in number to convince
draining = 0.025 #Draining per timestep