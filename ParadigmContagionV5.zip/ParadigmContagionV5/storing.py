# -*- coding: utf-8 -*-
"""
Created on Thu Jun  4 09:01:28 2020

@author: luja
"""
import numpy as np
import CSPComplexContagionConfig as var
import pandas as pd
idx = pd.IndexSlice             # needed for slicing multi-index dataframes (pandas)

'configurate dataframes'
col = list(range(1, var.runs+1))

weights = pd.DataFrame(index=['Weights Up','Weights Down'], columns=list(range(1, len(var.weights_up)+1)))
weights.loc['Weights Up'] = var.weights_up
weights.loc['Weights Down'] = var.weights_down
weights=weights.T

index = pd.MultiIndex.from_frame(weights) 
t = list(range(0, var.tmax+1))
col = list(range(1, var.runs+1))

stat_consensus = pd.DataFrame(index=index, columns= col) 
stat_check = pd.DataFrame(index=index, columns= col)

stat_cont = pd.DataFrame(index=index, columns=t)  
frames = [stat_cont, stat_cont, stat_cont, stat_cont]
stat_contagion = pd.concat([stat_cont]*var.runs, keys=col, names=['Run'])

