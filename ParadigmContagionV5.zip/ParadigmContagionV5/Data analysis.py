import csv
import sys

'''
Check if everything went okay
'''
with open('stat_check.csv') as stat_check:
    check_reader = csv.reader(stat_check, delimiter=',')
    line_count = 0
    for row in check_reader:
        if line_count != 0:
            for run in range(2,len(row)):
                if not bool(row[run]): #If something went wrong during writing, stop data analysis
                    sys.exit()
        line_count += 1

'''
Determine the weights, the amount of runs and tmax
'''
with open('stat_contagion.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    nLines = 0 #Number of lines in the file
    weights = [] #The weights, first element is weight down, second element is weight up
    nRuns = 0 #The number of runs
    for row in csv_reader:
        if nLines == 1:
            run = row[0]
            tmax = len(row)-3
        if run == row[0]:
            weights.append([row[1],row[2]])
        nLines += 1
    nRuns = int((nLines-1)/len(weights))

'''
The empty array of data is made, based on the amount of weights and the tmax
'''
data = [] #data[t][weight_nr] gives the average amount of convinced nodes at time t, with weights weights[weight_nr]
single_t = []
for weight in range(len(weights)):
    single_t.append(0)
for t in range(tmax):
    data.append(single_t.copy())

'''
Read out the data and put it in the data array
'''

with open('stat_contagion.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0

    for row in csv_reader:
        if line_count != 0:
            for weight in range(5):
                if not ((line_count - weight - 1)/5)%1:
                    for t in range(3,len(row)):
                        data[t-3][weight] += int(row[t])/nRuns
        line_count += 1