'''
Aart van Bochove
Grigorios Kyrpizidis
Luja Kockritz
Zeb Nemeth

https://github.com/ZebNemeth/ComplexContagion

'''

import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
#import math
#import numpy as np
#import os
#os.chdir(r"C:\Users\luja\Documents\GSS\Complex_Systems_Project\ComplexContagion-ParadigmContagion")

from past.builtins import execfile

#execfile('Setup.py')  
execfile('Storing.py') 

from NodeLabeling import labelNode, getConenr, getLevelnr, getNodenr, getNodes
from InterconalEdges import interconalEdges
from NetworkGenerator import conalGraphGenerator
from Convincing import seeding, convincing_cumulative
from Reset import resetNetwork

import CSPComplexContagionConfig as var

save = True # Set to True to save data in csv format

idx = pd.IndexSlice             # needed for slicing multi-index dataframes (pandas)
seeded =[]

for run in range(1,var.runs+1):
    'Generate Cones'
    weightUp = var.weights_up[0]
    weightDown = var.weights_down[0]
    G = conalGraphGenerator(var.weightNeutral, weightUp, weightDown, var.nCones, var.nLevels, var.nNodes, var.nInferiors, var.nRingNeighbors)
    
    if var.interconal:
        'Add interconal edges'
        G.add_weighted_edges_from( interconalEdges( var.friendliness, var.friendLevel, var.friendQuality) )
    
    seeded.clear
    seeded = seeding(G, var.ini_convinced, var.ini_convinced_neighbors, var.level_start, getNodes, getLevelnr)
    
    for case in range(1, len(var.weights_up)+1):
        print("case",case,"of ",len(var.weights_up),"of run",run,"of",var.runs)

        if var.cumulative:
            conv_tot, consensus, cover=convincing_cumulative(G, seeded, var.tmax, var.to_convince, var.draining)
            stat_contagion.loc[idx[run, weightUp, weightDown], :] = conv_tot
            stat_consensus.loc[idx[weightUp, weightDown],run] = consensus
            stat_check.loc[idx[weightUp, weightDown],run] = cover
            
            
        'Graph is drawn'
        #nx.draw(G, node_size=10, edge_color='grey')
        #plt.show()
        
        if case == len(var.weights_up):
            continue
            
        'set network to new weights' 
        resetNetwork(G, var.nCones, var.nLevels, var.nNodes, var.nInferiors, var.nRingNeighbors, weightUp = var.weights_up[case], weightDown = var.weights_down[case])
          
        weightUp = var.weights_up[case]
        weightDown = var.weights_down[case]
        
        'rest convincing level'
        nx.set_node_attributes(G, 0, name='conv_lev') 
        for node in seeded:
            G.node[node]['conv_lev']=1    
            
if save:
    stat_consensus.to_csv('stat_consensus.csv')
    stat_check.to_csv('stat_check.csv')
    stat_contagion.to_csv('stat_contagion.csv')