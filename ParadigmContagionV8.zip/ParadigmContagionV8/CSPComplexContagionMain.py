'''
Aart van Bochove
Grigorios Kyrpizidis
Luja Kockritz
Zeb Nemeth

https://github.com/ZebNemeth/ComplexContagion

'''

import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
import timeit
#import math
#import numpy as np
#import os
#os.chdir(r"C:\Users\luja\Documents\GSS\Complex_Systems_Project\ComplexContagion-ParadigmContagion")

from past.builtins import execfile

#execfile('Setup.py')  
execfile('storing.py') 

from NodeLabeling import labelNode, getConenr, getLevelnr, getNodenr, getNodes
from InterconalEdges import interconalEdges
from NetworkGenerator import conalGraphGenerator
from Convincing import seeding, convincing_cumulative
from Reset import resetNetwork

import CSPComplexContagionConfig as var

save = True # Set to True to save data in csv format

idx = pd.IndexSlice             # needed for slicing multi-index dataframes (pandas)
seeded =[]

'Generate Cones'
weightUp = 0
weightDown = 0
G = conalGraphGenerator(var.weightNeutral, weightUp, weightDown, var.nCones, var.nLevels, var.nNodes, var.nInferiors, var.nRingNeighbors)

if var.interconal:
    'Add interconal edges'
    G.add_weighted_edges_from( interconalEdges( var.friendliness, var.friendLevel, var.friendQuality) )

startAll = timeit.default_timer() # start timer

for run in range(1,var.runs+1):
    startPart = timeit.default_timer() # start timer

    seeded.clear
    seeded = seeding(G, var.ini_convinced, var.ini_convinced_neighbors, var.level_start, getNodes, getLevelnr)
    
    for case in range(0, var.nCases):
        'set network to new weights'
        resetNetwork(G, var.nCones, var.nLevels, var.nNodes, var.nInferiors, var.nRingNeighbors, weightUp = weights_up[case], weightDown = weights_down[case])

        'seeding'
        for node in seeded:
            G.node[node]['conv_lev']=1    
          
        weightUp = weights_up[case]
        weightDown = weights_down[case]

        print("case",case+1,"of",var.nCases,"of run",run,"of",var.runs)

        if var.cumulative:
            conv_tot, consensus, cover=convincing_cumulative(G, seeded, var.tmax, var.to_convince, var.draining)
            stat_contagion.loc[idx[run, weightDown, weightUp], :] = conv_tot
            stat_consensus.loc[idx[weightDown, weightUp],run] = consensus
            stat_check.loc[idx[weightDown, weightUp],run] = cover
                 
        'Graph is drawn'
        #nx.draw(G, node_size=10, edge_color='grey')
        #plt.show()

    stop = timeit.default_timer() # end timer
    print("This took",round(stop-startPart,1),"seconds")
    timeLeftSeconds = (stop-startAll)/(run)*(var.runs-run)
    print("Estimated time left =", int(timeLeftSeconds/60), "minutes and", timeLeftSeconds-int(timeLeftSeconds/60)*60, "seconds")
    print("")
                    
if save:
    stat_consensus.to_csv('stat_consensus.csv')
    stat_check.to_csv('stat_check.csv')
    stat_contagion.to_csv('stat_contagion.csv')