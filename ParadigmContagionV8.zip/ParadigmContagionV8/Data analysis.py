import csv
import sys
import numpy as np
import matplotlib.pyplot as plt

'''
Check if everything went okay
'''
with open('stat_check.csv') as stat_check:
    check_reader = csv.reader(stat_check, delimiter=',')
    line_count = 0
    for row in check_reader:
        if line_count != 0:
            for run in range(2,len(row)):
                if not bool(row[run]): #If something went wrong during writing, stop data analysis
                    sys.exit()
        line_count += 1

'''
Determine the weights, the amount of runs and tmax
'''
with open('stat_contagion.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    nLines = 0 #Number of lines in the file
    weights = [] #The weights, first element is weight down, second element is weight up
    nRuns = 0 #The number of runs
    for row in csv_reader:
        if nLines == 1:
            run = row[0]
            tmax = len(row)-3
        if run == row[0]:
            weights.append([float(row[1]),float(row[2])])
        nLines += 1
    nRuns = int((nLines-1)/len(weights))

'''
The empty array of mean data is made, based on the amount of weights and the tmax
'''
data = [] #data[t][weight_nr] gives the average amount of convinced nodes at time t, with weights weights[weight_nr]
single_t = []
for weight in range(len(weights)):
    single_t.append(0)
for t in range(tmax):
    data.append(single_t.copy())

'''
Read out the data and put it in the data array
'''

with open('stat_contagion.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0

    for row in csv_reader:
        if line_count != 0:
            for weight in range(len(weights)):
                if not ((line_count - weight - 1)/len(weights))%1:
                    for t in range(3,len(row)):
                        data[t-3][weight] += int(row[t])/(nRuns*484)
        line_count += 1

'''
Write mean in file
'''
        
with open('contagion_mean.csv', 'w') as csv_output:
    writer = csv.writer(csv_output)
    allrows = []
    toprow = ["Run","Weight down","Weight up"]
    for i in range(-1,200): toprow.append(i+1)
    allrows.append(toprow)
#    writer.writerow(toprow)
    for i in range(0,len(weights)):
        rowcontent = [1,weights[i][0],weights[i][1]]
        for j in range(0,tmax): rowcontent.append(data[j][i])
#        writer.writerow(rowcontent)
        allrows.append(rowcontent)
    writer.writerows(allrows)
    
'''
The empty array of standard deviation data is made, based on the amount of weights and the tmax
'''

std = [] #std[t][weight_nr] gives the std of the convinced nodes at time t, with weights weights[weight_nr]
single_t = []
for weight in range(len(weights)):
    single_t.append(0)
for t in range(tmax):
    std.append(single_t.copy())

'''
Caculate standarddeviation
'''

with open('stat_contagion.csv') as std_file:
    csv_reader = csv.reader(std_file, delimiter=',')
    line_count = 0

    for row in csv_reader:
        if line_count != 0:
            for weight in range(len(weights)):
                
                if not ((line_count - weight - 1)/len(weights))%1:
                    for t in range(3,len(row)):
                        std[t-3][weight] += (int(row[t])/(484)-data[t-3][weight])**2
                        #print(int(row[t])/(484)-data[t-3][weight])
                        #print("weight =",weight)
        line_count += 1

for weight in range(len(weights)):
    for t in range(3,len(row)):
        std[t-3][weight] = (1/(nRuns-1)*std[t-3][weight])**0.5


#print(weights)
t = np.arange(601)

for i in range(5):
    conv = np.array(data).T[i]
    standdev = np.array(std).T[i]
    plt.plot(t,conv,label = "$w_{up}$ = " + str(weights[i][1]))
    plt.xlabel("time step")
    plt.ylabel("Convincing level (%)")
plt.legend(title = ("$w_{down}$ = " + str(weights[i][0])))
#plt.savefig("conv_time.png", dpi=1024)
#plt.show()
maxStd = 0
for i in std:
    for j in i:
        if j > maxStd: maxStd = j
print(maxStd/(100)**0.5)
'''
for i in range(5,9):
    conv = np.array(data).T[i]
    plt.plot(t,conv)
plt.show()

for i in range(9,12):
    conv = np.array(data).T[i]
    plt.plot(t,conv)
plt.show()

for i in range(12,14):
    conv = np.array(data).T[i]
    plt.plot(t,conv)
plt.show()

for i in range(14,15):
    conv = np.array(data).T[i]
    plt.plot(t,conv)
plt.show()
'''