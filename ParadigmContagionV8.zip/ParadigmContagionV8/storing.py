# -*- coding: utf-8 -*-
"""
Created on Thu Jun  4 09:01:28 2020

@author: luja
"""
#import numpy as np
import CSPComplexContagionConfig as var
import pandas as pd
idx = pd.IndexSlice             # needed for slicing multi-index dataframes (pandas)

'configurate dataframes'
index = pd.MultiIndex.from_product([var.weights, var.weights], names=['Weight down', 'Weight up']) 

t = list(range(0, var.tmax+1))
col = list(range(1, var.runs+1))

stat_consensus = pd.DataFrame(index=index, columns= col) 
stat_check = pd.DataFrame(index=index, columns= col)
stat_cont = pd.DataFrame(index=index, columns=t)  

for i in var.weights[:]:
    for j in var.weights[:]:
        if i < j:
            stat_consensus=stat_consensus.drop(index=idx[i,j])
            stat_check=stat_check.drop(index=idx[i,j])
            stat_cont = stat_cont.drop(index=idx[i,j])

#stat_consensus=stat_consensus.drop(index=[idx[0.35,0.45],idx[0.15,0.45],idx[0.15,0.35],idx[0.05,0.45],idx[0.05,0.35],idx[0.05,0.15],idx[0.05,0.25],idx[0.15,0.25],idx[0.25,0.45],idx[0.25,0.35]])
#stat_check=stat_check.drop(index=[idx[0.35,0.45],idx[0.15,0.45],idx[0.15,0.35],idx[0.05,0.45],idx[0.05,0.35],idx[0.05,0.15],idx[0.05,0.25],idx[0.15,0.25],idx[0.25,0.45],idx[0.25,0.35]])
#stat_cont = stat_cont.drop(index=[idx[0.35,0.45],idx[0.15,0.45],idx[0.15,0.35],idx[0.05,0.45],idx[0.05,0.35],idx[0.05,0.15],idx[0.05,0.25],idx[0.15,0.25],idx[0.25,0.45],idx[0.25,0.35]])
weight_list = stat_cont.index.tolist()
stat_contagion = pd.concat([stat_cont]*var.runs, keys=col, names=['Run'])

weights_down=[x[0] for x in weight_list]
weights_up=[x[1] for x in weight_list]

print(weight_list)